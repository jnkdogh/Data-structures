package col106.assignment3.Election;

public class BST<T extends Comparable, E extends Comparable>{

	/*public static void main(String[] args) {
		BST<Integer, Integer> obj = new BST<>();
		Candidate c1 = new Candidate("Cand1" , "1" , "S1" , "D1" , "C1" , "P1" , "1200");
		Candidate c2 = new Candidate("Cand2" , "100" , "S1" , "D1" , "C1" , "P2" , "1000");
		Candidate c3 = new Candidate("Cand3" , "101" , "S1" , "D1" , "C1" , "P3" , "1500");
		Candidate c4 = new Candidate("Cand4" , "102" , "S1" , "D1" , "C1" , "P4" , "2000");
		Candidate c5 = new Candidate("Cand5" , "105" , "S1" , "D1" , "C1" , "P5" , "500");
		Candidate c6 = new Candidate("Cand6" , "2" , "S1" , "D2" , "C2" , "P2" , "4000");
		Candidate c7 = new Candidate("Cand7" , "3" , "S2" , "D3" , "C3" , "P3" , "2100");
		Candidate c8 = new Candidate("Cand8" , "4" , "S3" , "D4" , "C4" , "P4" , "800");
		Candidate c9 = new Candidate("Cand9" , "5" , "S3" , "D5" , "C5" , "P6" , "1600");
		Candidate c10 = new Candidate("Cand6" , "2" , "S1" , "D2" , "C2" , "P2" , "500");
		obj.insert(5,7,c1);
		obj.insert(4,9,c2);	
		obj.insert(3,4,c3);
		obj.insert(2,5,c4);
		obj.insert(1,3,c5);
		obj.insert(15,2,c6);
		obj.insert(0,10,c7);
		obj.insert(10,11,c8);
		obj.insert(11,12,c9);
		obj.update(2, 500, c10);
		// obj.insert(12,13);
		// obj.insert(13,14);
		// obj.insert(6,8);
		// obj.insert(7,6);
		// obj.insert(8,1);
		// obj.delete(1);
		// obj.prev(8);
		// System.out.println(obj.prev(7).valuebst);
		// obj.update(7,0);
		// System.out.println(obj.height());
		// obj.insert(11,31);
	//" S"yst"em".ou"t."pri"nt"ln("obj."prev(5).valuebst);
		// obj.update(3,8);
		// obj.search(3);
		// obj.print_level(2);
		// System.out.println(obj.valuebst);
		obj.printBST();
		// System.out.println(obj.search(7).keybst + ", " + obj.search(7).valuebst);
	}*/

	public T keybst;
	public E valuebst;
	public Candidate cand;
	public BST left;
	public BST right;

	public BST()
	{
		//root is added here (to call the constructor we need root)
		this.keybst = null;
		this.valuebst = null;
		this.left = null;
		this.right = null;
		this.cand = null;
	}


	@SuppressWarnings("unchecked")
	public BST search(T key)
	{
		BST temp = this;
		// System.out.println("search");
		// System.out.println(temp.valuebst);
		if(temp.left==null && temp.right==null && temp.keybst!=key)
		{
			// System.out.println("temp==null");
			// System.out.println(temp.valuebst);
			return null;
		}
		else if (temp.left==null && temp.right!=null && temp.keybst!=key) 
		{
			return temp.right.search(key);
		}
		else if(temp.keybst==key)
		{
			// System.out.println("temp.keybst==key");
			// System.out.println(temp.valuebst);
			return temp;
		}
		else
		{
			// System.out.println("else");
			// System.out.println(temp.valuebst);
			BST a = temp.left.search(key);
			// System.out.println("a");
			// System.out.println(a.valuebst);
			if(a==null)
			{
				if(temp.right!=null)
				{
					return temp.right.search(key);
				}
				else
				{
					return null;
				}
			}
			else
			{
				return a;
			}
		}
	}

	@SuppressWarnings("unchecked")
    public void insert(T key, E value, Candidate c) {
		//write your code here
		// System.out.println("insert");
		// System.out.println(key);
		// System.out.println(value);
		BST temp = this;
		// System.out.println("insert2");
		if(temp.valuebst!=null)
		{
			// System.out.println("a");
			while(temp!= null)
			{
				// System.out.println("while start");
				if(value.compareTo(temp.valuebst)<0)
				{
					// System.out.println("c");
					if(temp.left!=null)
					{
						// System.out.println("d");
						temp = temp.left;
					}

					else
					{
						// System.out.println("e");
						BST obj = new BST();
						obj.valuebst=value;
						obj.keybst=key;
						obj.cand=c;
						temp.left = obj;
						temp = temp.left;
						// System.out.println("while end");
						break;
					}
				}

				if(value.compareTo(temp.valuebst)>0)
				{
					// System.out.println("c1");
					if(temp.right!=null)
					{
						// System.out.println("d1");
						temp = temp.right;
					}

					else//else mistake to be noted
					{
						// System.out.println("e1");
						BST obj = new BST();
						obj.valuebst=value;
						obj.keybst=key;
						obj.cand=c;
						temp.right = obj;
						temp = temp.right;
						break;
					}
				}		
			}	
		}

		if(temp.valuebst==null)
		{
			// System.out.println("a2");
			temp.keybst=key;
			temp.valuebst=value;
			temp.cand=c;			
		}		
    }

    @SuppressWarnings("unchecked")
    public void update(T key, E value, Candidate c) {
		//write your code here
		// System.out.println("update");
		BST temp = this;
		// System.out.println("delete");
		temp.delete(key);
		// System.out.println("update insert");
		temp.insert(key, value, c);
		// System.out.println("insert2");
		
    }

    @SuppressWarnings("unchecked")
    public void delete(T key) {
		//write your code here
		BST temp = this;
		BST ump = this;
		temp = temp.search(key);
		BST pv = ump.prev(temp.keybst);	
		// System.out.println("a");
		int a = 0;
		int b = 0;
		if(a==0)
		{	
		if(temp.right!=null)
		{
			a+=1;
			// System.out.println("b");
			BST temp2 = temp.right;
			BST temp4 = temp.right;
			BST temp3 = temp.left;
			BST prev = null;
			// System.out.println("b2");
			
			if(temp2.left!=null)
			{
				// System.out.println("p");
				b+=1;
				while(temp2.left!=null)
				{
					// System.out.println("c");
					prev = temp2;
					temp2 = temp2.left;
				}
				if(temp2.right!=null)
				{
					// System.out.println("c2");
					prev.left=temp2.right;
					temp.keybst=temp2.keybst;
					temp.valuebst=temp2.valuebst;
					temp.cand=temp2.cand;
					temp.right=temp4;
					temp.left=temp3;
				}
				else
				{
					// System.out.println("c3");
					prev.left=null;
					temp.valuebst=temp2.valuebst;
					temp.keybst=temp2.keybst;
					temp.cand=temp2.cand;
					temp.right=temp4;
					temp.left=temp3;					
				}			
			}
			else
			{
				// System.out.println("x");
				b+=1;
				temp.keybst=temp2.keybst;
				temp.valuebst=temp2.valuebst;
				temp.cand=temp2.cand;
				temp.right=temp2.right;
				temp.left=temp3;
			}
			// System.out.println("z");

		}

		if(b==0)
		{
		if(temp.right==null && temp.left!=null)
		{
			a+=1;
			// System.out.println("d");
			BST temp2 = temp.left;
			BST temp4 = temp.left;
			BST temp3 = temp.right;
			BST prev = null;
			// System.out.println("d2");
			if(temp2.right!=null)
			{
				// System.out.println("d3");
				while(temp2.right!=null)
				{
					// System.out.println("e");
					prev = temp2;
					temp2 = temp2.right;
				}
				if(temp2.left!=null)
				{
					// System.out.println("e1");
					prev.right=temp2.left;
					temp.valuebst=temp2.valuebst;
					temp.keybst=temp2.keybst;
					temp.cand=temp2.cand;
					temp.left=temp4;
					temp.right=temp3;
				}
				else
				{
					// System.out.println("e2");
					prev.right=null;
					temp.keybst=temp2.keybst;
					temp.valuebst=temp2.valuebst;
					temp.cand=temp2.cand;
					temp.left=temp4;
					temp.right=temp3;					
				}			
			}
			else
			{
				// System.out.println("g");
				temp.valuebst=temp2.valuebst;
				temp.keybst=temp2.keybst;
				temp.cand=temp2.cand;
				temp.left=temp2.left;
				temp.right=temp3;
			}		
		}
		}
		}

		if(a==0)
		{
		if(temp.right==null && temp.left==null)
		{
			if(pv==null)
			{
				temp=null;
				temp.valuebst=null;
				temp.keybst=null;	
				temp.cand=null;			
			}
			else
			{
				if(pv.right==temp)
				{
					pv.right=null;
				}
				else
				{
					pv.left=null;
				}
			}
			// System.out.println("f");
			temp.valuebst=null;
			temp.keybst=null;
			temp.cand=null;
		}
		}
    }

    @SuppressWarnings("unchecked")
    public int height(){
    	BST temp = this;
    	if(temp.right == null && temp.left == null)
    	{
    		return 1;
    	}
    	else if (temp.right!=null && temp.left==null) 
    	{
    		int right_height = temp.right.height();
    		return right_height+1;
    	}
    	else if (temp.right==null && temp.left!=null) 
    	{
    		int left_height = temp.left.height();
	   		return left_height+1;
    	}
    	else
    	{
    		int left_height = temp.left.height();
    		int right_height = temp.right.height();
    		if(right_height > left_height)
    		{
    			return right_height+1;
    		}
    		else if (right_height == left_height) 
    		{
    			return right_height+1;
    		}
    		else
    		{
    			return left_height+1;
    		}
    	}
    }

    @SuppressWarnings("unchecked")
    public void print_level(int a){
    	BST temp = this;
    	if(a==1)
    	{
    		System.out.println(temp.cand.name + ", " +  temp.cand.candID + ", " + temp.cand.state + ", " + temp.cand.district + ", " + temp.cand.constituency + ", " + temp.cand.party + ", " + temp.cand.votes);
    	}
    	else if (a>1) 
    	{
    		if(temp.right!=null && temp.left!=null)
    		{
    			int b = a-1;
    			temp.left.print_level(b);
    			temp.right.print_level(b);
    		}
    		else if (temp.right!=null && temp.left==null) 
    		{
    			int b = a-1;
    			temp.right.print_level(b);
    		}
     		else if (temp.right==null && temp.left!=null) 
    		{
    			int b = a-1;
    			temp.left.print_level(b);
    		}   		
    	}
    }

    /*public Comparable return_key_at_level(int a){
    	BST temp = this;
    	if(a==1)
    	{
			return temp.keybst;
    	}
    	else if (a>1) 
    	{
    		if(temp.right!=null && temp.left!=null)
    		{
    			int b = a-1;
    			return temp.left.return_key_at_level(b);
    			return temp.right.return_key_at_level(b);
    		}
    		else if (temp.right!=null && temp.left==null) 
    		{
    			int b = a-1;
    			return temp.right.return_key_at_level(b);
    		}
     		else if (temp.right==null && temp.left!=null) 
    		{
    			int b = a-1;
    			return temp.left.return_key_at_level(b);
    		}   		
    	}
    }*/

    @SuppressWarnings("unchecked")
    public void printBST () {
    	BST temp = this;
    	int h = temp.height();
    	for (int i=1; i<=h ;i++ ) 
    	{
    		temp.print_level(i);	
    	}
		//write your code here
    }

	@SuppressWarnings("unchecked")
	public BST prev(T key)
	{
		// System.out.println("prev");
		BST temp = this;
		// BST temp2 = this;
		BST prev = null;
		// System.out.println(temp.valuebst);
		if(temp.search(key)!=null)
		{
			// System.out.println("temp.search != null");
			// System.out.println(temp.valuebst);
			// System.out.println("a");
			while(temp.keybst!=key)
			{
				// System.out.println("while not equal");
				if(temp!=null)
				{
					// System.out.println("temp not null");
					if(temp.right!=null)
					{
					if(temp.right.search(key)!=null)
					{
						// System.out.println("in right subtree");
						// System.out.println(temp.valuebst);
						prev=temp;
						temp=temp.right;
						// System.out.println("assigning right");
						// System.out.println(temp.valuebst);
					}
					else
					{
						// System.out.println("d");
						// System.out.println("in left subtree");
						// System.out.println(temp.valuebst);
						prev=temp;
						temp=temp.left;
						// System.out.println("assigning left");
						// System.out.println(temp.valuebst);
					}
					}
					else
					{
						prev=temp;
						temp=temp.left;						
					}
				}
				else
				{
					// System.out.println("temp is null");
					return prev;
				}

			}
		}
		else
		{
			// System.out.println("temp search is null");
			// System.out.println("e");
			return null;
		}
		// System.out.println("i");
		return prev;
	}   

}